




<!DOCTYPE html>
<html>
    <head>
       <script data-ad-client="ca-pub-8637087401934308" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Faça Seu Login</title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="theme-color" content="#000000">

        <?php $__env->startSection('scripts'); ?>
            <?php echo Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/adminlte/admin.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('css/pterodactyl.css?t={cache-version}'); ?>

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        <?php echo $__env->yieldSection(); ?>
    </head>
    <body id="particles-js" class="hold-transition login-page">
        <div class="container">
            <div id="login-position-elements">
                <div class="login-logo">
                    <img src="/themes/pterodactyl/san.jpg" width="320px">
                </div>
                <?php echo $__env->yieldContent('content'); ?>
                <p class="small login-copyright text-center">
                 Hospedagem Localizada no  Canadá, Ant ddos, Conexão SFTP   
                </p>
            </div>
        </div>
       <div>
</div>


            <div class="login-corner-info small">
            <p>SAMP,MTA,TS3</p>        </div>

        <?php echo Theme::js('vendor/jquery/jquery.min.js?t={cache-version}'); ?>

        <?php echo Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}'); ?>

        <?php echo Theme::js('js/autocomplete.js?t={cache-version}'); ?>

        <?php echo Theme::js('vendor/particlesjs/particles.min.js?t={cache-version}'); ?>

        <script type="text/javascript">
            /* particlesJS.load(@dom-id, @path-json, @callback (optional)); */
            $(function () {
                
        </script>
    </body>
</html>
