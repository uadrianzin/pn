<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('base.errors.installing.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-8 col-md-offset-2 col-sm-10 col-sm-offset-1 col-xs-12">
        <div class="box box-info">
            <div class="progress progress-striped active">
                <div class="progress-bar progress-bar-info" style="width: 75%"></div>
            </div>
            <div class="box-body text-center">
                <p class="text-muted"><?php echo app('translator')->getFromJson('base.errors.installing.desc'); ?></p>
            </div>
            <div class="box-footer with-border">
                <a href="<?php echo e(URL::previous()); ?>"><button class="btn btn-info">&larr; <?php echo app('translator')->getFromJson('base.errors.return'); ?></button></a>
                <a href="/"><button class="btn btn-default"><?php echo app('translator')->getFromJson('base.errors.home'); ?></button></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>