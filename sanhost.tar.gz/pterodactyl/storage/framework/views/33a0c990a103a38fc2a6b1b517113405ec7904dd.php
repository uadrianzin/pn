




<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo e(config('app.name', 'Pterodactyl')); ?> - <?php echo $__env->yieldContent('title'); ?></title>
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">

        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="mask-icon" href="/favicons/safari-pinned-tab.svg" color="#bc6e3c">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="msapplication-config" content="/favicons/browserconfig.xml">
        <meta name="theme-color" content="#0e4688">

        <?php $__env->startSection('scripts'); ?>
            <?php echo Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/adminlte/admin.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/adminlte/colors/skin-blue.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}'); ?>

            <?php echo Theme::css('css/pterodactyl.css?t={cache-version}'); ?>

            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">

            <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
            <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
            <![endif]-->
        <?php echo $__env->yieldSection(); ?>
    </head>
    <body class="hold-transition skin-blue fixed sidebar-mini">
        <div class="wrapper">
            <header class="main-header">
                <a href="<?php echo e(route('index')); ?>" class="logo">
                    <span><?php echo e(config('app.name', 'Pterodactyl')); ?></span>
                </a>
                <nav class="navbar navbar-static-top"></nav>
            </header>
            <div class="content-wrapper" style="margin-left: 0;">
                <section class="content-header">
                    <?php echo $__env->yieldContent('content-header'); ?>
                </section>
                <section class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
            </div>
            <footer class="main-footer" style="margin-left: 0;">
                <div class="pull-right hidden-xs small text-gray">
                    <strong>v</strong> <?php echo e(config('app.version')); ?>

                </div>
                Hospedagem A Cada Dia Atualizando.
            </footer>
        </div>
        <?php $__env->startSection('footer-scripts'); ?>
            <?php echo Theme::js('js/laroute.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/jquery/jquery.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/slimscroll/jquery.slimscroll.min.js?t={cache-version}'); ?>

            <?php echo Theme::js('vendor/adminlte/app.min.js?t={cache-version}'); ?>

        <?php echo $__env->yieldSection(); ?>
    </body>
</html>
