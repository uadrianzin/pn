<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('base.index.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('base.index.header'); ?><small><?php echo app('translator')->getFromJson('base.index.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('strings.servers'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title"><?php echo app('translator')->getFromJson('base.index.list'); ?></h3>
                <div class="box-tools search01">
                    <form action="<?php echo e(route('index')); ?>" method="GET">
                        <div class="input-group input-group-sm">
                            <input type="text" name="query" class="form-control pull-right" value="<?php echo e(request()->input('query')); ?>" placeholder="<?php echo app('translator')->getFromJson('strings.search'); ?>">
                            <div class="input-group-btn">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th><?php echo app('translator')->getFromJson('strings.gerenciar'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.node'); ?></th>
                            <th><?php echo app('translator')->getFromJson('strings.connection'); ?></th>
                            <th class="text-center hidden-sm hidden-xs"><?php echo app('translator')->getFromJson('strings.memory'); ?></th>
                            <th class="text-center hidden-sm hidden-xs"><?php echo app('translator')->getFromJson('strings.cpu'); ?></th>
                            <th class="text-center hidden-sm hidden-xs"><?php echo app('translator')->getFromJson('strings.disk'); ?></th>
                        </tr>
                        <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="dynamic-update" data-server="<?php echo e($server->uuidShort); ?>">
                              
                               <td><a href="<?php echo e(route('server.index', $server->uuidShort)); ?>">Gerenciar Servidor</a></td> 
                                <td><?php echo e($server->getRelation('node')->name); ?></td>
                                <td><code><?php echo e($server->getRelation('allocation')->alias); ?>:<?php echo e($server->getRelation('allocation')->port); ?></code></td>
                                <td class="text-center hidden-sm hidden-xs"><span data-action="memory">--</span> / <?php echo e($server->memory === 0 ? '∞' : $server->memory); ?> MB</td>
                                <td class="text-center hidden-sm hidden-xs"><span data-action="cpu" data-cpumax="<?php echo e($server->cpu); ?>">--</span> %</td>
                                <td class="text-center hidden-sm hidden-xs"><span data-action="disk">--</span> / <?php echo e($server->disk === 0 ? '∞' : $server->disk); ?> MB </td>
                                <td class="text-center">
                                </td>
                                <?php if($server->node->maintenance_mode): ?>
                                    <td class="text-center">
                                        <span class="label label-warning"><?php echo app('translator')->getFromJson('strings.under_maintenance'); ?></span>
                                    </td>
                                <?php else: ?>
                                    </td>
                                <?php endif; ?>
                            </tr>
                            <?php if(! empty($server->description)): ?>
                                <tr class="server-description">
                                    <td colspan="8"><p class="text-muted small no-margin"><?php echo e(str_limit($server->description, 400)); ?></p></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php if($servers->hasPages()): ?>
                <div class="box-footer">
                    <div class="col-md-12 text-center"><?php echo $servers->appends(['query' => Request::input('query')])->render(); ?></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <script>
        $('tr.server-description').on('mouseenter mouseleave', function (event) {
            $(this).prev('tr').css({
                'background-color': (event.type === 'mouseenter') ? '#f5f5f5' : '',
            });
        });
    </script>
    <?php echo Theme::js('js/frontend/serverlist.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>