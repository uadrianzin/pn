<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->getFromJson('base.api.new.header'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1><?php echo app('translator')->getFromJson('base.api.new.header'); ?><small><?php echo app('translator')->getFromJson('base.api.new.header_sub'); ?></small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('index')); ?>"><?php echo app('translator')->getFromJson('strings.home'); ?></a></li>
        <li class="active"><?php echo app('translator')->getFromJson('navigation.account.api_access'); ?></li>
        <li class="active"><?php echo app('translator')->getFromJson('base.api.new.header'); ?></li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <form method="POST" action="<?php echo e(route('account.api.new')); ?>">
            <div class="col-sm-6 col-xs-12">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="form-group">
                            <label class="control-label" for="memoField">Description <span class="field-required"></span></label>
                            <input id="memoField" type="text" name="memo" class="form-control" value="<?php echo e(old('memo')); ?>">
                        </div>
                        <p class="text-muted">Set an easy to understand description for this API key to help you identify it later on.</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xs-12">
                <div class="box box-primary">
                    <div class="box-body">
                        <div class="form-group">
                            <label class="control-label" for="allowedIps">Allowed Connection IPs <span class="field-optional"></span></label>
                            <textarea id="allowedIps" name="allowed_ips" class="form-control" rows="5"><?php echo e(old('allowed_ips')); ?></textarea>
                        </div>
                        <p class="text-muted">If you would like to limit this API key to specific IP addresses enter them above, one per line. CIDR notation is allowed for each IP address. Leave blank to allow any IP address.</p>
                    </div>
                    <div class="box-footer">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-success btn-sm pull-right">Create</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>