<?php $__env->startSection('title'); ?>
    List Servers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content-header'); ?>
    <h1>Servers<small>All servers available on the system.</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(route('admin.index')); ?>">Admin</a></li>
        <li class="active">Servidores</li>
    </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xs-12">
        <div class="box box-primary">
            <div class="box-header with-border">
                <h3 class="box-title">Lista de Servidores</h3>
                <div class="box-tools">
                    <form action="<?php echo e(route('admin.servers')); ?>" method="GET">
                        <div class="input-group input-group-sm">
                            <input type="text" name="query" class="form-control pull-right" style="width:30%;" value="<?php echo e(request()->input('query')); ?>" placeholder="Search Servers">
                            <div class="input-group-btn">
                                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                <a href="<?php echo e(route('admin.servers.new')); ?>"><button type="button" class="btn btn-sm btn-primary" style="border-radius: 0 3px 3px 0;margin-left:-1px;">CRIAR NOVO</button></a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="box-body table-responsive no-padding">
                <table class="table table-hover">
                    <tbody>
                        <tr>
                            <th>NOME</th>
                            <th>UUID</th>
                            <th>DONO</th>
                            <th>REGIÃO</th>
                            <th></th>
                            <th></th>
                            <th></th>
                        </tr>
                        <?php $__currentLoopData = $servers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $server): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-server="<?php echo e($server->uuidShort); ?>">
                                <td><a href="<?php echo e(route('admin.servers.view', $server->id)); ?>"><?php echo e($server->name); ?></a></td>
                                <td><code title="<?php echo e($server->uuid); ?>"><?php echo e($server->uuid); ?></code></td>
                                <td><a href="<?php echo e(route('admin.users.view', $server->user->id)); ?>"><?php echo e($server->user->username); ?></a></td>
                                <td><a href="<?php echo e(route('admin.nodes.view', $server->node->id)); ?>"><?php echo e($server->node->name); ?></a></td>
                                <td>
                                    <code><?php echo e($server->allocation->alias); ?>:<?php echo e($server->allocation->port); ?></code>
                                </td>
                                <td class="text-center">
                                    <?php if($server->suspended): ?>
                                        <span class="label bg-maroon">Suspended</span>
                                    <?php elseif(! $server->installed): ?>
                                        <span class="label label-warning">Installing</span>
                                    <?php else: ?>
                                        <span class="label label-success">Active</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <a class="btn btn-xs btn-default" href="<?php echo e(route('server.index', $server->uuidShort)); ?>"><i class="fa fa-wrench"></i></a>
                                    <a class="btn btn-xs btn-default console-popout" href="<?php echo e(route('server.console', $server->uuidShort)); ?>"><i class="fa fa-terminal"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php if($servers->hasPages()): ?>
                <div class="box-footer with-border">
                    <div class="col-md-12 text-center"><?php echo $servers->appends(['query' => Request::input('query')])->render(); ?></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-scripts'); ?>
    ##parent-placeholder-45585b3461af0151e9d2a64e937701e41f93ebd3##
    <script>
        $('.console-popout').on('click', function (event) {
            event.preventDefault();
            window.open($(this).attr('href'), 'Pterodactyl Console', 'width=800,height=400');
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>